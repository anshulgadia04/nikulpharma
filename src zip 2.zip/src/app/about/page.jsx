import React from 'react'
import AboutUsPage from '@/components/AboutUsPage'

export default function AboutPage() {
  return (
    <AboutUsPage />
  )
}