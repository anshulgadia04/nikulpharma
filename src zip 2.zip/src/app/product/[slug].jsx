import React, { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { motion, useInView, animate } from 'framer-motion';
import {
  ArrowLeft, Check, Phone, Mail, Settings, Zap as HighEfficiency, CheckSquare, Clock, Users, HardHat, Target, FlaskConical, Factory, HeartPulse, Microscope as ResearchIcon, Shield, Pill
} from 'lucide-react';
import { getProductBySlug } from '@/utils/products';

// --- Animation Variants ---
const sectionVariants = {
  hidden: { opacity: 0, y: 40 },
  visible: {
    opacity: 1,
    y: 0,
    transition: { duration: 0.8, ease: [0.25, 1, 0.5, 1], staggerChildren: 0.1 },
  },
};

const itemVariants = {
  hidden: { opacity: 0, y: 20 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.7, ease: [0.25, 1, 0.5, 1] } },
};

// --- Animated Counter Component ---
function Counter({ to, suffix = "" }) {
  const ref = React.useRef(null);
  const inView = useInView(ref, { once: true, margin: "-100px" });

  useEffect(() => {
    if (!inView || !ref.current) return;
    const node = ref.current;
    const controls = animate(0, to, {
      duration: 2.5,
      ease: "easeOut",
      onUpdate(value) {
        node.textContent = Math.round(value).toLocaleString();
      },
    });
    return () => controls.stop();
  }, [to, inView]);

  return <span ref={ref}>0</span>;
}

// --- Main Page Component ---
export default function ProductDetailPage() {
  const { slug } = useParams();
  const navigate = useNavigate();
  const [product, setProduct] = useState(null);

  useEffect(() => {
    window.scrollTo(0, 0);
    const p = getProductBySlug(slug);
    setProduct(p || null);
  }, [slug]);

  if (!product) {
    return (
      <div className="min-h-screen bg-white flex items-center justify-center p-6">
        <div className="text-center">
          <h1 className="text-4xl font-semibold text-gray-900">Product not found</h1>
          <button onClick={() => navigate(-1)} className="mt-8 inline-flex items-center text-gray-600 hover:text-gray-900 transition-colors">
            <ArrowLeft className="w-5 h-5 mr-2" /> Back
          </button>
        </div>
      </div>
    );
  }

  // --- Data for Page Sections (dynamically created from product data) ---
  const getSpecValue = (key, fallback) => {
    const spec = Object.entries(product.specs).find(([k]) => k.toLowerCase().includes(key.toLowerCase()));
    if (!spec) return fallback;
    const match = spec[1].match(/[\d.]+/);
    return match ? parseFloat(match[0]) : fallback;
  };

  const stats = [
    { label: 'Efficiency', value: getSpecValue('Efficiency', 90), suffix: '%' },
    { label: 'Throughput', value: getSpecValue('capacity', 458), suffix: 'kg/h' },
    { label: 'Particle Size', value: getSpecValue('particle size', 9), suffix: 'μm' },
    { label: 'Operation', value: 24, suffix: '/7' },
  ];
  
  const featureCards = [
    { icon: Target, title: "Ultra-Precision", text: `Achieve particle sizes down to ${stats[2].value} microns.` },
    { icon: HighEfficiency, title: "High Efficiency", text: `Process up to ${stats[1].value}kg/hour.` },
    { icon: CheckSquare, title: "GMP Compliant", text: "Full compliance with all manufacturing standards." },
    { icon: Clock, title: "24/7 Operation", text: "Designed for continuous operation with minimal maintenance." },
    { icon: Shield, title: "Quality Assured", text: "ISO 9001 certified with comprehensive quality control." },
    { icon: Users, title: "Expert Support", text: "Dedicated technical support and training programs." },
  ];

  const applicationsData = [
    { icon: Pill, title: "Pharmaceuticals", desc: "Tablet formulations, API processing, and drug development.", points: ["Tablet Manufacturing", "API Processing", "Drug Development", "Quality Control"] },
    { icon: ResearchIcon, title: "Research & Development", desc: "Laboratory-scale grinding for research and testing.", points: ["Sample Preparation", "Research Studies", "Method Development", "Analytical Testing"] },
    { icon: Factory, title: "Manufacturing", desc: "Large-scale production grinding operations.", points: ["Bulk Processing", "Production Lines", "Quality Assurance", "Batch Processing"] },
    { icon: HeartPulse, title: "Healthcare", desc: "Medical device and healthcare product manufacturing.", points: ["Medical Devices", "Healthcare Products", "Surgical Instruments", "Diagnostic Tools"] },
  ];

  return (
    <div className="bg-white">
      <div className="h-20" /> {/* Spacer */}
      
      {/* Hero (as per video) */}
      <motion.header
        initial="hidden" animate="visible" variants={sectionVariants}
        className="py-20 text-center"
      >
        <div className="max-w-4xl mx-auto px-6">
            <h1 className="text-5xl md:text-6xl font-light text-gray-800 mb-4">{product.name}</h1>
        </div>
      </motion.header>

      {/* How It Works Section */}
      <motion.section
        initial="hidden" whileInView="visible" viewport={{ once: true, amount: 0.3 }} variants={sectionVariants}
        className="py-20 bg-gray-50"
      >
        <div className="max-w-6xl mx-auto px-6">
            <div className="text-center mb-16">
                <h2 className="text-4xl font-light text-gray-900">How It Works</h2>
                <p className="text-gray-600 mt-3 max-w-3xl mx-auto">Our precision disc grinder utilizes advanced mechanical principles to deliver consistent, high-quality pharmaceutical grinding results.</p>
            </div>
            <div className="grid lg:grid-cols-2 gap-12 items-center">
                <motion.div variants={itemVariants}>
                    <h3 className="text-2xl font-semibold text-gray-800 mb-4">Precision Grinding Mechanism</h3>
                    <p className="text-gray-600 mb-6">{product.description}</p>
                    <h4 className="font-semibold text-gray-800 mb-3">Key Components:</h4>
                    <ul className="space-y-2">
                        {product.features.slice(0, 4).map((comp, i) => (
                            <li key={i} className="flex items-center text-gray-700">
                                <Check className="w-5 h-5 text-blue-600 mr-3" /> {comp}
                            </li>
                        ))}
                    </ul>
                </motion.div>
                <motion.div variants={itemVariants} className="aspect-square bg-white rounded-2xl shadow-xl border border-gray-200 p-4">
                    <img src={product.image} alt={product.name} className="w-full h-full object-contain" />
                </motion.div>
            </div>
        </div>
      </motion.section>
      
      {/* Key Features Section */}
      <motion.section
        initial="hidden" whileInView="visible" viewport={{ once: true, amount: 0.2 }} variants={sectionVariants}
        className="py-24"
      >
        <div className="max-w-6xl mx-auto px-6">
            <div className="text-center mb-12">
                <h2 className="text-4xl font-light text-gray-900">Key Features</h2>
                <p className="text-gray-600 mt-2">Engineered for excellence with cutting-edge technology and precision manufacturing.</p>
            </div>
            <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
                {featureCards.map((card, i) => (
                    <motion.div key={i} variants={itemVariants} className="bg-white rounded-2xl border border-gray-100 shadow-lg p-6 text-center hover:shadow-xl hover:-translate-y-1 transition-all">
                        <div className="w-16 h-16 bg-blue-100 text-blue-600 rounded-lg flex items-center justify-center mb-5 mx-auto">
                           <card.icon strokeWidth={1.5} className="w-8 h-8"/>
                        </div>
                        <h3 className="font-semibold text-gray-800 mb-1 text-lg">{card.title}</h3>
                        <p className="text-gray-600 text-sm">{card.text}</p>
                    </motion.div>
                ))}
            </div>
        </div>
      </motion.section>

      {/* Applications Section */}
      <motion.section
        initial="hidden" whileInView="visible" viewport={{ once: true, amount: 0.2 }} variants={sectionVariants}
        className="py-24 bg-gray-50"
      >
        <div className="max-w-6xl mx-auto px-6">
            <div className="text-center mb-12">
                <h2 className="text-4xl font-light text-gray-900">Applications</h2>
                <p className="text-gray-600 mt-2">Serving diverse industries with precision grinding solutions.</p>
            </div>
            <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
                {applicationsData.map((app, i) => (
                    <motion.div key={i} variants={itemVariants} className="bg-white rounded-2xl border border-gray-200 shadow-lg p-6 flex flex-col">
                      <div className="flex items-center mb-4">
                        <div className="w-12 h-12 bg-blue-100 text-blue-600 rounded-lg flex items-center justify-center mr-4 flex-shrink-0">
                          <app.icon strokeWidth={1.5}/>
                        </div>
                        <h3 className="text-lg font-semibold text-gray-800">{app.title}</h3>
                      </div>
                      <p className="text-gray-600 text-sm mb-4">
                        {app.desc}
                      </p>
                      <ul className="space-y-2 text-sm">
                        {app.points.map((point, j) => (
                          <li key={j} className="flex items-center text-gray-700">
                             <div className="w-1.5 h-1.5 bg-blue-500 rounded-full mr-3 flex-shrink-0"></div>
                             {point}
                          </li>
                        ))}
                      </ul>
                    </motion.div>
                ))}
            </div>
        </div>
      </motion.section>

      {/* Specifications & Highlights Section */}
      <motion.section 
        initial="hidden" whileInView="visible" viewport={{ once: true, amount: 0.2 }} variants={sectionVariants}
        className="py-24 bg-white"
      >
        <div className="max-w-6xl mx-auto px-6">
            <div className="text-center mb-16">
                <h2 className="text-4xl font-light text-gray-900">Specifications & Highlights</h2>
                <p className="text-gray-600 mt-2">Technical specifications and performance metrics.</p>
            </div>

            <div className="grid grid-cols-2 lg:grid-cols-4 gap-6 mb-20">
                {stats.map(stat => (
                    <motion.div key={stat.label} variants={itemVariants} className="text-center bg-white p-6 rounded-2xl shadow-xl border border-gray-100">
                        <p className="text-5xl font-bold text-blue-600">
                            <Counter to={stat.value} />{stat.suffix}
                        </p>
                        <p className="text-gray-500 mt-2">{stat.label}</p>
                    </motion.div>
                ))}
            </div>

            <div className="grid lg:grid-cols-2 gap-x-12 gap-y-16">
                <motion.div variants={itemVariants}>
                    <h3 className="text-2xl font-semibold text-gray-800 mb-6">Technical Specifications</h3>
                    <div className="space-y-4">
                        {Object.entries(product.specs).map(([key, value]) => (
                            <div key={key} className="flex justify-between items-center border-b border-gray-200 pb-4">
                                <span className="text-gray-600">{key}</span>
                                <span className="font-semibold text-gray-900 text-lg">{value}</span>
                            </div>
                        ))}
                    </div>
                </motion.div>
                <motion.div variants={itemVariants}>
                     <h3 className="text-2xl font-semibold text-gray-800 mb-6">Key Highlights</h3>
                     <ul className="space-y-4">
                        {product.features.map((highlight, i) => (
                            <li key={i} className="flex items-start text-gray-700 leading-relaxed">
                                <div className="w-6 h-6 flex-shrink-0 flex items-center justify-center rounded-full bg-blue-100 text-blue-600 mr-4 mt-1">
                                    <Check className="w-4 h-4"/> 
                                </div>
                                {highlight}
                            </li>
                        ))}
                    </ul>
                </motion.div>
            </div>
        </div>
      </motion.section>

      {/* Final CTA */}
      <motion.section 
        initial="hidden" whileInView="visible" viewport={{ once: true, amount: 0.5 }} variants={sectionVariants}
        className="py-24 bg-gradient-to-r from-blue-600 to-blue-800 text-white"
      >
        <div className="max-w-4xl mx-auto px-6 text-center">
            <h2 className="text-4xl font-bold mb-4">Ready to Transform Your Manufacturing?</h2>
            <p className="text-lg text-blue-100 mb-8 max-w-2xl mx-auto">Get a personalized quote and discover how our precision disc grinder can enhance your pharmaceutical process.</p>
            <div className="flex flex-col sm:flex-row flex-wrap gap-4 justify-center">
                <a href="tel:+1234567890" className="inline-flex items-center justify-center px-8 py-3 border-2 border-white text-white rounded-xl font-semibold hover:bg-white hover:text-blue-700 transition-all duration-300">
                    <Phone className="w-5 h-5 mr-2" /> Call Now
                </a>
                <a href="mailto:info@nikulpharma.com" className="inline-flex items-center justify-center px-8 py-3 border-2 border-white text-white rounded-xl font-semibold hover:bg-white hover:text-blue-700 transition-all duration-300">
                    <Mail className="w-5 h-5 mr-2" /> Email Us
                </a>
            </div>
        </div>
      </motion.section>

    </div>
  );
}